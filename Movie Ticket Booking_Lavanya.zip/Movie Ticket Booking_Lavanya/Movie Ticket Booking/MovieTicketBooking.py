"""

Title: Movie Ticket Booking Application

Author: Lavanya B

Created at:10-June-2022

Updated at: 13-June-2022

Reviewed by:Naveen Subramaniam

Reviewed at: 13-June-2022

"""

from Validation import Validation

validation = Validation()
validation.validate()

