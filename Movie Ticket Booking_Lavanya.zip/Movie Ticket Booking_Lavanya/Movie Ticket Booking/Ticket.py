import Validation as Valid


class Ticket:

    name = ""
    password = ""
    Seats = []

    # seat allocation
    for i in range(0, 600):
        Seats.append(0);

    def __init__(self, name, password):
        self.name = name
        self.password = password

    def getName(self):
        return self.name

    def getPassword(self):
        return self.password

    # view seats

    def viewSeats(self):
        print("\n============================= SCREEN =================================\n")
        for j in range(0, 600):

            if (j % 30 == 0):
                print("\n")
                print(self.Seats[j], end=" ")

            elif (j % 10 == 0):
                print("      ", self.Seats[j], end=" ")

            else:
                print(self.Seats[j], end=" ")

        self.getOption()

    # booking movie tickets
    def bookTicket(self):
        print("-------------------------------------------------")
        print("\n\nEnter a Seat Number : ")
        print("-------------------------------------------------")
        sNum = int(input())
        if self.Seats[sNum - 1] == 0:
            self.Seats[sNum - 1] = 1
            print("\nYour Seat Booked Successfully")
            print("-------------------------------------------------")

        else:
            print("-------------------------------------------------")
            print("\nSeat Already Booked... Try Another")
            print("-------------------------------------------------")
        self.viewSeats()
        self.getOption()

    # cancelling movie tickets
    def cancelTicket(self):
        print("\n-------------------------------------------------")
        print("\nEnter your seat number to cancel")
        print("-------------------------------------------------")
        sNum = int(input())
        if self.Seats[sNum - 1] == 1:
            self.Seats[sNum - 1] = 0
            print("\nYour Ticket Cancelled Successfully")
            print("-------------------------------------------------")


        else:
            print("\nTicket is not yet Booked")
            print("-------------------------------------------------")
        self.viewSeats()
        self.getOption()

        # showing details to user

    def getOption(self):
        print("\n-------------------------------------------------")
        print("\n1.View Seats \n2.Book Ticket \n3.Cancel a Ticket \n4.LogOut\n")
        print("-------------------------------------------------")
        options = input()  # user input for choise

        if options == "1":
            self.viewSeats()

        elif options == "2":
            self.bookTicket()

        elif options == "3":
            self.cancelTicket()

        elif options == "4":
            self.logOut()

        else:
            print("Input Invalid")
            self.getOption()

     #LogOut
    def logOut(self):
        Valid.Validation.validate()
