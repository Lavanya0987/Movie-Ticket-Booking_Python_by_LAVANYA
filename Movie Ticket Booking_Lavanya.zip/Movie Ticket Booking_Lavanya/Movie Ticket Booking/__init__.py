
from Validation import Validation


class Program:
    def abc(self):
        validation = Validation();
        validation.validate();
