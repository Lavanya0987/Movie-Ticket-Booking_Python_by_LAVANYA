from Ticket import Ticket


class Validation:
    name = ""
    password = ""
    userDetails = [];

    @classmethod
    def validate(self):

        # user-inputs
        # Existing User Details

        person1 = Ticket("ASM", "Password@123")

        person2 = Ticket("Lavanya", "Password@123")

        person3 = Ticket("Karthik", "Password@123")

        person4 = Ticket("Dhilip", "Password@123")

        person5 = Ticket("Sai", "Password@123")

        person6 = Ticket("Saranya", "Password@123")

        # appending user inputs to List

        self.userDetails.append(person1)

        self.userDetails.append(person2)

        self.userDetails.append(person3)

        self.userDetails.append(person4)

        self.userDetails.append(person5)

        self.userDetails.append(person6)

        print("\n------------------------------------------------------")
        print("\n------------Welcome to our ABC Theater-------------------\n1.LogIn\n2.Signup\n\nEnter 1 or 2 to continue....")
        print("\n-------------------------------------------------")

        choice = input()

        # login
        if choice == "1":
            try:

                # Taking User Inputs
                print("\n-------------------------------------------------")
                print("\nEnter Username")

                name = input()

                print("\nEnter password")

                password = input()
                print("\n-------------------------------------------------")

                # User Detail validation

                count = 0;

                for ticket in self.userDetails:
                    if name == ticket.getName() and password == ticket.getPassword():
                        print("\n-------------------------------------------------")
                        print("\nLogged In Successfully")
                        print("\n-------------------------------------------------")

                        count = 1;

                        ticket.getOption()

                # if user not present in list,this will execute
                if (count == 0):
                    print("\n-------------------------------------------------")
                    print("\n\nPlease enter Valid Details\n")
                    print("\n-------------------------------------------------")
                    self.validate()


            # for invalid details
            except(Exception):

                print("\n-------------------------------------------------")
                print("\nEnter Valid Details")
                print("\n-------------------------------------------------")
                Validation.validate()

        # Signup
        elif choice == "2":

            # Taking user inputs
            print("\n-------------------------------------------------")
            print("\nEnter Username")

            self.name = input()

            print("\nEnter password")

            self.password = input()

            print("\n-------------------------------------------------")

            # new user details adding
            newUser = Ticket(self.name, self.password)

            self.userDetails.append(newUser)

            print("\n-------------------------------------------------")
            print("\nRegistered Successfully")
            print("\n-------------------------------------------------")
            newUser.getOption()

        else:
            print("\n-------------------------------------------------")
            print("\nInput Invalid")
            print("\n-------------------------------------------------")
            self.validate()
